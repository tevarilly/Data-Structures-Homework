#include <iostream>
#include <vector>
#include <cstdlib>
#include <cmath>
#include <cassert>

#include "polygons.h"

// Put the constructors in here? I don't know how that works

// Function that returns the number of right angles in the shape
int Polygon::NumberRight()
{
	int angle_count = 0;

	// If you have a triangle
	if(points.size() == 3)
	{
		double Angle1;
		double Angle2;
		double Angle3;

		// Each of the three angles
		Angle1 = Angle(points[2],points[0],points[1]);
		Angle2 = Angle(points[0],points[1],points[2]);
		Angle3 = Angle(points[1],points[2],points[0]);

		// You should hopefully never have more than one right angle
		// 	 on a triangle
		if(Angle1 == 90 || Angle2 == 90 || Angle3 == 90)
		{
			angle_count = 1;
		}

		return angle_count;
	}

	// If you have a quadrilateral
	if(points.size() == 4)
	{
		double Angle1;
		double Angle2;
		double Angle3;
		double Angle4;

		// All four angles
		Angle1 = Angle(points[3],points[0],points[1]);
		Angle2 = Angle(points[0],points[1],points[2]);
		Angle3 = Angle(points[1],points[2],points[3]);
		Angle4 = Angle(points[2],points[3],points[0]);

		if(Angle1 == 90)
		{
			angle_count += 1;
		}

		if(Angle2 == 90)
		{
			angle_count += 1;
		}

		if(Angle3 == 90)
		{
			angle_count += 1;
		}

		if(Angle4 == 90)
		{
			angle_count += 1;
		}

		// If none of the angles are 90 degrees
		if(angle_count == 0)
		{
			return 0;
		}

		else if(angle_count == 1)
		{
			return 1;
		}

		// If two of the angles are 90 degrees
		else if(angle_count == 2)
		{
			return 2;
		}

		// If you have a square or a rectangle
		else
		{
			assert (angle_count == 4);

			return 4;
		}
	}

	// We shouldn't ever reach this
	return 0;
}

// Function that returns the number of sides that are parallel to each other
// (Can only be 0, 2, or 4)
int Polygon::NumberParallel()
{
	// No triangle will have parallel sides
	assert (points.size() == 4);

	int parallel_count = 0;

	Vector side_1(points[0],points[1]);
	Vector side_2(points[1],points[2]);
	Vector side_3(points[2],points[3]);
	Vector side_4(points[3],points[0]);

	if(Parallel(side_1,side_2))
	{
		parallel_count += 1;
	}

	if(Parallel(side_1,side_3))
	{
		parallel_count += 1;
	}

	if(Parallel(side_1,side_4))
	{
		parallel_count += 1;
	}

	if(Parallel(side_2,side_3))
	{
		parallel_count += 1;
	}

	if(Parallel(side_2,side_4))
	{
		parallel_count += 1;
	}

	if(Parallel(side_3,side_4))
	{
		parallel_count += 1;
	}

	// No sides are parallel
	if(parallel_count == 0)
	{
		return 0;
	}

	// Two sides are parallel
	else if(parallel_count == 1)
	{
		return 2;
	}

	// Two sets of sides are parallel
	else
	{
		assert (parallel_count == 2);
		return 4;
	}

	// We shouldn't get to this
	return 0;
}

// Function that returns the number of sides that are equal in length
int Polygon::NumberEqualSides()
{
	int side_count = 0;

	// If you have a triangle
	if(points.size() == 3)
	{
		// The three sides of the triangle
		Vector side_1(points[0],points[1]);
		Vector side_2(points[1],points[2]);
		Vector side_3(points[2],points[0]);

		if( EqualSides(side_1.Length(), side_2.Length()) )
		{
			side_count += 1;
		}

		if( EqualSides(side_2.Length(), side_3.Length()) )
		{
			side_count += 1;
		}

		if( EqualSides(side_3.Length(), side_1.Length()) )
		{
			side_count += 1;
		}

		// None of the sides are equal
		if(side_count == 0)
		{
			return 0;
		}

		// If two sides are equal to each other
		else if(side_count == 1)
		{
			return 2;
		}

		// Note: side_count should never be 2
		else
		{
			assert (side_count == 3);
			return 3;
		}
	}

	// If you have a quadrilateral
	else if (points.size() == 4)
	{
		// The four sides of the quadrilateral
		Vector side_1(points[0],points[1]);
		Vector side_2(points[1],points[2]);
		Vector side_3(points[2],points[3]);
		Vector side_4(points[3],points[0]);

		if(side_1.Length() == side_2.Length())
		{
			side_count += 1;
		}

		if(side_1.Length() == side_3.Length())
		{
			side_count += 1;
		}

		if(side_1.Length() == side_4.Length())
		{
			side_count += 1;
		}

		if(side_2.Length() == side_3.Length())
		{
			side_count += 1;
		}

		if(side_2.Length() == side_4.Length())
		{
			side_count += 1;
		}

		if(side_3.Length() == side_4.Length())
		{
			side_count += 1;
		}

		// None of the sides are equal
		if(side_count == 0)
		{
			return 0;
		}

		// If one pair of sides are equal
		else if(side_count == 1)
		{
			return 1;
		}

		else if (side_count == 2)
		{
			return 2;
		}

		// If three sides are equal, half the cases will pass
		else if(side_count == 3)
		{
			return 3;
		}

		// If all the sides are equal
		else
		{
			assert (side_count == 6);
			return 4;
		}
	}

	// We shouldn't get to this
	return 0;
}

// Function that returns the number of equal angles in a quadrilateral
// (Can only be 0, 2, or 4)
int Polygon::NumberEqualAngles()
{
	assert (points.size() == 4);

	int equal_angle_count = 0;

	double Angle1;
	double Angle2;
	double Angle3;
	double Angle4;

	// All four angles
	Angle1 = Angle(points[3],points[0],points[1]);
	Angle2 = Angle(points[0],points[1],points[2]);
	Angle3 = Angle(points[1],points[2],points[3]);
	Angle4 = Angle(points[2],points[3],points[0]);

	if(EqualAngles(Angle1,Angle2))
	{
		equal_angle_count += 1;
	}

	if(EqualAngles(Angle1,Angle3))
	{
		equal_angle_count += 1;
	}

	if(EqualAngles(Angle1,Angle4))
	{
		equal_angle_count += 1;
	}

	if(EqualAngles(Angle2,Angle3))
	{
		equal_angle_count += 1;
	}

	if(EqualAngles(Angle2,Angle4))
	{
		equal_angle_count += 1;
	}

	if(EqualAngles(Angle3,Angle4))
	{
		equal_angle_count += 1;
	}

	if(equal_angle_count == 0)
	{
		return 0;
	}

	else if(equal_angle_count == 1)
	{
		return 2;
	}

	else if(equal_angle_count == 2)
	{
		return 2;
	}

	else if(equal_angle_count == 3)
	{
		return 3;
	}

	else if(equal_angle_count == 4)
	{
		return 3;
	}

	else if(equal_angle_count == 5)
	{
		return 3;
	}

	else if(equal_angle_count == 6)
	{
		return 4;
	}

	return 0;
}

int Polygon::NumberTriangleEqualAngles()
{
	int angle_count = 0;

	double Angle1;
	double Angle2;
	double Angle3;

	// Each of the three angles
	Angle1 = Angle(points[2],points[0],points[1]);
	Angle2 = Angle(points[0],points[1],points[2]);
	Angle3 = Angle(points[1],points[2],points[0]);

	if( EqualAngles(Angle1, Angle2))
	{
		angle_count += 1;
	}

	if( EqualAngles(Angle1, Angle3))
	{
		angle_count += 1;
	}

	if( EqualAngles(Angle2, Angle3))
	{
		angle_count += 1;
	}

	if(angle_count == 0)
	{
		return 0;
	}

	else if(angle_count == 1)
	{
		return 2;
	}

	else
	{
		return 3;
	}
}

// Function that returns the number of 180 degree angles in a quadrilateral
int Polygon::Number180()
{
	int number_180 = 0;

	if(points.size() == 3)
	{
		double Angle1;
		double Angle2;
		double Angle3;

		// Each of the three angles
		Angle1 = Angle(points[2],points[0],points[1]);
		Angle2 = Angle(points[0],points[1],points[2]);
		Angle3 = Angle(points[1],points[2],points[0]);

		if(ReflexAngle(Angle1))
		{
			number_180 += 1;
		}

		if(ReflexAngle(Angle2))
		{
			number_180 += 1;
		}

		if(ReflexAngle(Angle3))
		{
			number_180 += 1;
		}

	}

	if(points.size() == 4)
	{
		double Angle1;
		double Angle2;
		double Angle3;
		double Angle4;

		// All four angles
		Angle1 = Angle(points[3],points[0],points[1]);
		Angle2 = Angle(points[0],points[1],points[2]);
		Angle3 = Angle(points[1],points[2],points[3]);
		Angle4 = Angle(points[2],points[3],points[0]);

		if(ReflexAngle(Angle1))
		{
			number_180 += 1;
		}

		if(ReflexAngle(Angle2))
		{
			number_180 += 1;
		}

		if(ReflexAngle(Angle3))
		{
			number_180 += 1;
		}

		if(ReflexAngle(Angle4))
		{
			number_180 += 1;
		}
	}

	return number_180;
}

// Function that checks whether the quadrilateral has at least two equal and ajacent angles
bool Polygon::TwoAdjacentAngles()
{
	assert (points.size() == 4);

	bool adjacent = false;

	double Angle1;
	double Angle2;
	double Angle3;
	double Angle4;

	// All four angles
	Angle1 = Angle(points[3],points[0],points[1]);
	Angle2 = Angle(points[0],points[1],points[2]);
	Angle3 = Angle(points[1],points[2],points[3]);
	Angle4 = Angle(points[2],points[3],points[0]);

	if((Angle1 == Angle2) || (Angle2 == Angle3)
		|| (Angle3 == Angle4) || (Angle4 == Angle1))
	{
		adjacent = true;
	}

	return adjacent;
}

bool Polygon::HasAllEqualSides()
{
	if((points.size() == 4) && (NumberEqualSides() == 4))
	{
		return true;
	}

	else if((points.size() == 3) && (NumberEqualSides() == 3))
	{
		return true;
	}

	else
	{
		return false;
	}
}

bool Polygon::HasAllEqualAngles()
{
	if(points.size() == 4)
	{
		if(NumberEqualAngles() == 4 && !IsConcave())
		{
			return true;
		}
	}

	else if(points.size() == 3)
	{
		if(NumberTriangleEqualAngles() == 3)
		{
			return true;
		}
	}

	return false;
}

bool Polygon::HasARightAngle()
{
	if(NumberRight() > 0)
	{
		return true;
	}

	else
	{
		return false;
	}
}

bool Polygon::HasAnAcuteAngle()
{
	bool is_acute_angle = false;

	if(points.size() == 3)
	{
		double Angle1;
		double Angle2;
		double Angle3;

		// Each of the three angles
		Angle1 = Angle(points[2],points[0],points[1]);
		Angle2 = Angle(points[0],points[1],points[2]);
		Angle3 = Angle(points[1],points[2],points[0]);

		// Make sure at least one of the angles is greater than 90 degrees
		// (hopefully not more than that)
		if(Angle1 < 90 || Angle2 < 90 || Angle3 < 90)
		{
			is_acute_angle = true;
		}
	}

	else if (points.size() == 4)
	{
		double Angle1;
		double Angle2;
		double Angle3;
		double Angle4;

		// All four angles
		Angle1 = Angle(points[3],points[0],points[1]);
		Angle2 = Angle(points[0],points[1],points[2]);
		Angle3 = Angle(points[1],points[2],points[3]);
		Angle4 = Angle(points[2],points[3],points[0]);

		if(Angle1 < 90 || Angle2 < 90 || Angle3 < 90 || Angle4 < 90)
		{
			is_acute_angle = true;
		}
	}

	return is_acute_angle;
}

// Function that checks whether a triangle has an obtuse angle
bool Polygon::HasAnObtuseAngle()
{
	bool is_obtuse_angle = false;

	if(points.size() == 3)
	{
		double Angle1;
		double Angle2;
		double Angle3;

		// Each of the three angles
		Angle1 = Angle(points[2],points[0],points[1]);
		Angle2 = Angle(points[0],points[1],points[2]);
		Angle3 = Angle(points[1],points[2],points[0]);

		// Make sure at least one of the angles is greater than 90 degrees
		// (hopefully not more than that)
		if(ObtuseAngle(Angle1) || ObtuseAngle(Angle2) || ObtuseAngle(Angle3))
		{
			is_obtuse_angle = true;
		}
	}

	else if(points.size() == 4)
	{
		double Angle1;
		double Angle2;
		double Angle3;
		double Angle4;

		// All four angles
		Angle1 = Angle(points[3],points[0],points[1]);
		Angle2 = Angle(points[0],points[1],points[2]);
		Angle3 = Angle(points[1],points[2],points[3]);
		Angle4 = Angle(points[2],points[3],points[0]);

		if(ObtuseAngle(Angle1) || ObtuseAngle(Angle2) || ObtuseAngle(Angle3) || ObtuseAngle(Angle4))
		{
			is_obtuse_angle = true;
		}
	}

	return is_obtuse_angle;
}

bool Polygon::IsConvex()
{
	if(Number180() == 0)
	{
		return true;
	}

	else
	{
		return false;
	}
}

bool Polygon::IsConcave()
{
	if(Number180() != 0)
	{
		return true;
	}

	else
	{
		return false;
	}
}

// Accessor
std::string Polygon::getName()
{
	return name;
}