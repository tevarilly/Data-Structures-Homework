HOMEWORK 1: MORPHOLOGICAL IMAGE PROCESSING


NAME:  < Taylor Varilly >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< www.stackoverflow.com, www.cplusplus.com, Christopher Weir>

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < 30 >

OVERVIEW OF PERSONAL STATISTIC:
For my personal statistic, I performed linear regression on the values of games
won and matches won for each of the players, with games won being the y-value
and matches won being the x-value.  The resulting line shows a positive correlation
between games won and matches won. This way, if you knew how many games your 
favorite player won, you could estimate the matches won.

EXTRA CREDIT:
Describe your implementation changes to allow alternate structuring
elements (different size/shape).  Paste in sample command lines,
sample input & output and discuss the different results.



MISC. COMMENTS TO GRADER:  
The automatic homework grader is deducting points even on the cases when 
my formatting and output are identical to the expected output.