HOMEWORK 6: CARCASSONNE CONTEST


NAME:  < Taylor E Varilly >



COLLABORATORS AND OTHER RESOURCES:
< www.cplusplus.com, www.stackoverflow.com, Christopher Weir >



DESCRIPTION OF ANY PERFORMANCE IMPROVEMENTS/OPTIMIZATIONS:
(Most of my optimizations consisted of checking whether tile moves are valid before placing any tiles.
	This "cuts off" many branches from the recursive tree which results from placing tiles)



DESCRIBE INTERESTING NEW PUZZLES YOU CREATED: I didn't



SUMMARY OF YOUR PERFORMANCE ON ALL PUZZLES:
Puzzle 1:
	Using minumum board dimensions: 
		0 seconds
	-all_solutions and -allow_rotations:
		0 seconds
	No additional command line arguments:
		0 seconds
	
Puzzle 2:
	Using minumum board dimensions: 
		0 seconds
	No additional command line arguments:
		133.87 seconds

Puzzle 3:
	Using minumum board dimensions: 
		0 seconds
	-all_solutions and -allow_rotations:
		0.03 seconds

Puzzle 4:
	Using minumum board dimensions: 
		0.7 seconds
	Using minimum board dimensions -all_solutions and -allow_rotations:
		36.16 seconds

Puzzle 5:
	Using minumum board dimensions: 
		0 seconds
	Using minimum board dimensions -all_solutions and -allow_rotations:
		55.57 seconds

Puzzle 6:
	Using minumum board dimensions: 
		0.05 seconds
	-all_solutions:
		0.05 seconds

Puzzle 7:
	Using minumum board dimensions: 
		2.31 seconds
	-all_solutions and -allow_rotations:
		Too long

Puzzle 8:
	Using minumum board dimensions: 
		0 seconds
	-all_solutions and -allow_rotations:
		Too long

Puzzle 9:
	Using minumum board dimensions: 
		50.03 seconds
	-all_solutions and -allow_rotations:
		Too long

Correctness & approximate wall clock running time for various command
line arguments.
